from django.shortcuts import render,HttpResponse,redirect
from .models import Employee
from datetime import datetime
from django.db.models import Q

# Create your views here.
def index(request):
    return render(request,'index.html')

def all_emp(request):
    emps =Employee.objects.all()
    context ={
        'emps': emps
    }
    print(context)
    return render(request,'all_emp.html',context)


def add_emp(request):
    if request.method == 'POST':
        First_name = request.POST.get('First_name')
        last_name = request.POST.get('last_name')
        salary = int(request.POST.get('salary'))
        bonus = int(request.POST.get('bonus'))
        phoneno = int(request.POST.get('phoneno'))
        dept = request.POST.get('dept')
        location = request.POST.get('location')
        role = request.POST.get('role')
        new_emp = Employee(location=location, first_name = First_name, last_name = last_name, salary=salary,bonus=bonus,phone=phoneno, dept = dept, role= role, hire_date = datetime.now())
        new_emp.save()
        return redirect('/all_emp')
    elif request.method=='GET':
        return render(request,'add_emp.html')
    else:
        return HttpResponse("an exception occured")

def remove_emp(request):

        
    emps=Employee.objects.all()
    context = {
        'emps': emps
    }    
    return render(request,'Remove_emp.html',context)

def del_emp(request,emp_id):
    
    emp_to_be_removed =Employee.objects.get(id=emp_id)
    emp_to_be_removed.delete()
    return redirect('/remove_emp')
def filter_emp(request):
    if request.method== 'POST':
        name= request.POST.get("name")
        dept= request.POST.get("dept")
        role= request.POST.get("role")
        emps= Employee.objects.all()
        if name:
            emps = emps.filter(first_name__icontains =name) | emps.filter(last_name__icontains = name)
            context= {
                'emps':emps
            }
            return render(request,'all_emp.html',context)
        if dept:
            emps = emps.filter(dept = dept)
            context= {
                'emps':emps
            }
            return render(request,'all_emp.html',context)
        if role:
            emps = emps.filter(role = role)
            context= {
                'emps':emps
            }
            return render(request,'all_emp.html',context)


        elif request.method =='GET':
            return render(request,'filter_emp.html')
        else:
            return HttpResponse('an exception in this')

  
    
    return render(request,'filter_emp.html')
