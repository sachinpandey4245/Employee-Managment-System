from django.contrib import admin
from emp_app.models import Employee

# Register your models here.
admin.site.register(Employee)
